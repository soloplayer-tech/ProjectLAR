#include "ProjectLAR/UI/Public/LEquipmentPreviewActor.h"

#include "Camera/CameraComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/SceneComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Kismet/KismetMathLibrary.h"
#include "NiagaraComponent.h"
#include "ProjectLAR/Item/Public/LInventoryComponent.h"
#include "ProjectLAR/Player/Public/LPlayerCharacter.h"

ALEquipmentPreviewActor::ALEquipmentPreviewActor()
{
	PrimaryActorTick.bCanEverTick = false;
	SetActorEnableCollision(false);

	RootScene = CreateDefaultSubobject<USceneComponent>(TEXT("RootScene"));
	SetRootComponent(RootScene);

	PreviewMeshComp =
		CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("PreviewMeshComp"));
	PreviewMeshComp->SetupAttachment(RootScene);
	PreviewMeshComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	PreviewMeshComp->SetGenerateOverlapEvents(false);
	PreviewMeshComp->SetRelativeLocation(FVector(0.0f, 0.0f, 0.0f));
	PreviewMeshComp->SetRelativeRotation(FRotator(0.0f, -90.0f, 0.0f));
	PreviewMeshComp->SetCastShadow(false);

	PreviewWeaponMeshComp =
		CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PreviewWeaponMeshComp"));
	PreviewWeaponMeshComp->SetupAttachment(PreviewMeshComp);
	PreviewWeaponMeshComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	PreviewWeaponMeshComp->SetGenerateOverlapEvents(false);
	PreviewWeaponMeshComp->SetCastShadow(false);
	PreviewWeaponMeshComp->SetHiddenInGame(true);
	PreviewWeaponMeshComp->SetVisibility(false, true);

	PreviewWeaponNiagaraComp =
		CreateDefaultSubobject<UNiagaraComponent>(TEXT("PreviewWeaponNiagaraComp"));
	PreviewWeaponNiagaraComp->SetupAttachment(PreviewMeshComp);
	PreviewWeaponNiagaraComp->SetAutoActivate(false);
	PreviewWeaponNiagaraComp->SetHiddenInGame(true);
	PreviewWeaponNiagaraComp->SetVisibility(false, true);

	SceneCaptureComp =
		CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("SceneCaptureComp"));
	SceneCaptureComp->SetupAttachment(RootScene);
	SceneCaptureComp->SetRelativeLocation(FVector(320.0f, 0.0f, 112.0f));
	SceneCaptureComp->SetRelativeRotation(
		UKismetMathLibrary::FindLookAtRotation(
			SceneCaptureComp->GetRelativeLocation(),
			FVector(0.0f, 0.0f, 95.0f)
		)
	);
	SceneCaptureComp->FOVAngle = 30.0f;
	SceneCaptureComp->CaptureSource = SCS_FinalColorLDR;
	SceneCaptureComp->bCaptureEveryFrame = true;
	SceneCaptureComp->bCaptureOnMovement = false;
	SceneCaptureComp->PrimitiveRenderMode =
		ESceneCapturePrimitiveRenderMode::PRM_UseShowOnlyList;
	SceneCaptureComp->ShowOnlyActors.Add(this);

	KeyLightComp = CreateDefaultSubobject<UPointLightComponent>(TEXT("KeyLightComp"));
	KeyLightComp->SetupAttachment(RootScene);
	KeyLightComp->SetRelativeLocation(FVector(240.0f, -120.0f, 230.0f));
	KeyLightComp->SetIntensity(18000.0f);
	KeyLightComp->SetAttenuationRadius(900.0f);

	FillLightComp = CreateDefaultSubobject<UPointLightComponent>(TEXT("FillLightComp"));
	FillLightComp->SetupAttachment(RootScene);
	FillLightComp->SetRelativeLocation(FVector(140.0f, 180.0f, 160.0f));
	FillLightComp->SetIntensity(7000.0f);
	FillLightComp->SetAttenuationRadius(800.0f);
}

void ALEquipmentPreviewActor::SetRenderTarget(
	UTextureRenderTarget2D* InRenderTarget
)
{
	if (SceneCaptureComp)
	{
		SceneCaptureComp->TextureTarget = InRenderTarget;
	}
}

void ALEquipmentPreviewActor::SetupFromPlayer(ALPlayerCharacter* PlayerCharacter)
{
	if (!PlayerCharacter || !PreviewMeshComp)
	{
		return;
	}

	USkeletalMeshComponent* SourceMeshComp = PlayerCharacter->GetMesh();

	if (!SourceMeshComp)
	{
		return;
	}

	PreviewMeshComp->SetSkeletalMesh(SourceMeshComp->GetSkeletalMeshAsset());
	PreviewMeshComp->SetAnimInstanceClass(SourceMeshComp->GetAnimClass());
	PreviewMeshComp->SetHiddenInGame(false);
	PreviewMeshComp->SetVisibility(true, true);

	for (int32 MaterialIndex = 0; MaterialIndex < SourceMeshComp->GetNumMaterials(); ++MaterialIndex)
	{
		PreviewMeshComp->SetMaterial(
			MaterialIndex,
			SourceMeshComp->GetMaterial(MaterialIndex)
		);
	}

	ApplyWeaponVisual(PlayerCharacter);

	if (SceneCaptureComp)
	{
		SceneCaptureComp->CaptureScene();
	}
}

void ALEquipmentPreviewActor::ApplyWeaponVisual(
	ALPlayerCharacter* PlayerCharacter
)
{
	if (!PlayerCharacter || !PreviewWeaponMeshComp || !PreviewWeaponNiagaraComp)
	{
		return;
	}

	ULInventoryComponent* InventoryComponent =
		PlayerCharacter->GetInventoryComponent();

	FLInventorySlot EquippedWeaponSlot;
	const bool bHasEquippedWeapon =
		InventoryComponent
		&& InventoryComponent->GetEquippedWeaponSlot(EquippedWeaponSlot)
		&& EquippedWeaponSlot.ItemData;

	if (!bHasEquippedWeapon)
	{
		PreviewWeaponMeshComp->SetStaticMesh(nullptr);
		PreviewWeaponMeshComp->SetHiddenInGame(true);
		PreviewWeaponMeshComp->SetVisibility(false, true);

		PreviewWeaponNiagaraComp->Deactivate();
		PreviewWeaponNiagaraComp->SetAsset(nullptr);
		PreviewWeaponNiagaraComp->SetHiddenInGame(true);
		PreviewWeaponNiagaraComp->SetVisibility(false, true);
		return;
	}

	UStaticMeshComponent* SourceWeaponMeshComp =
		PlayerCharacter->GetWeaponVisualStaticMeshComponent();
	UNiagaraComponent* SourceWeaponNiagaraComp =
		PlayerCharacter->GetWeaponVisualNiagaraComponent();

	if (SourceWeaponMeshComp && SourceWeaponMeshComp->GetStaticMesh())
	{
		FName SocketToUse = SourceWeaponMeshComp->GetAttachSocketName();

		if (!SocketToUse.IsNone() && !PreviewMeshComp->DoesSocketExist(SocketToUse))
		{
			SocketToUse = NAME_None;
		}

		PreviewWeaponMeshComp->AttachToComponent(
			PreviewMeshComp,
			FAttachmentTransformRules::SnapToTargetNotIncludingScale,
			SocketToUse
		);
		PreviewWeaponMeshComp->SetRelativeTransform(
			SourceWeaponMeshComp->GetRelativeTransform()
		);
		PreviewWeaponMeshComp->SetStaticMesh(SourceWeaponMeshComp->GetStaticMesh());
		PreviewWeaponMeshComp->SetHiddenInGame(false);
		PreviewWeaponMeshComp->SetVisibility(true, true);
	}
	else
	{
		PreviewWeaponMeshComp->SetStaticMesh(nullptr);
		PreviewWeaponMeshComp->SetHiddenInGame(true);
		PreviewWeaponMeshComp->SetVisibility(false, true);
	}

	if (SourceWeaponNiagaraComp && SourceWeaponNiagaraComp->GetAsset())
	{
		USceneComponent* PreviewNiagaraParent = PreviewMeshComp;

		if (SourceWeaponNiagaraComp->GetAttachParent() == SourceWeaponMeshComp
			&& PreviewWeaponMeshComp->GetStaticMesh())
		{
			PreviewNiagaraParent = PreviewWeaponMeshComp;
		}

		PreviewWeaponNiagaraComp->AttachToComponent(
			PreviewNiagaraParent,
			FAttachmentTransformRules::KeepRelativeTransform
		);
		PreviewWeaponNiagaraComp->SetRelativeTransform(
			SourceWeaponNiagaraComp->GetRelativeTransform()
		);
		PreviewWeaponNiagaraComp->SetAsset(SourceWeaponNiagaraComp->GetAsset());
		PreviewWeaponNiagaraComp->SetHiddenInGame(false);
		PreviewWeaponNiagaraComp->SetVisibility(true, true);
		PreviewWeaponNiagaraComp->Activate(true);
	}
	else
	{
		PreviewWeaponNiagaraComp->Deactivate();
		PreviewWeaponNiagaraComp->SetAsset(nullptr);
		PreviewWeaponNiagaraComp->SetHiddenInGame(true);
		PreviewWeaponNiagaraComp->SetVisibility(false, true);
	}
}
