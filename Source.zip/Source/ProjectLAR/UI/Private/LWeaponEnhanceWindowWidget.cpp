#include "ProjectLAR/UI/Public/LWeaponEnhanceWindowWidget.h"

#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Blueprint/WidgetTree.h"
#include "Components/Border.h"
#include "Components/Button.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/HorizontalBox.h"
#include "Components/HorizontalBoxSlot.h"
#include "Components/Image.h"
#include "Components/Overlay.h"
#include "Components/OverlaySlot.h"
#include "Components/SizeBox.h"
#include "Components/TextBlock.h"
#include "Components/VerticalBox.h"
#include "Components/VerticalBoxSlot.h"
#include "Engine/Texture2D.h"
#include "InputCoreTypes.h"
#include "Kismet/GameplayStatics.h"
#include "ProjectLAR/Item/Public/LItemDataAsset.h"
#include "ProjectLAR/Player/Public/LPlayerCharacter.h"
#include "ProjectLAR/UI/Public/LUIDragDropOperation.h"

TWeakObjectPtr<ULWeaponEnhanceWindowWidget>
	ULWeaponEnhanceWindowWidget::ActiveWeaponEnhanceWindow;

void ULWeaponEnhanceWindowWidget::SetObservedPlayer(
	ALPlayerCharacter* InObservedPlayerCharacter
)
{
	ObservedPlayerCharacter = InObservedPlayerCharacter;
	RefreshEnhanceWindow();
}

bool ULWeaponEnhanceWindowWidget::TrySetTargetFromInventorySlot(
	int32 SlotIndex
)
{
	ULInventoryComponent* InventoryComponent =
		ResolveInventoryComponent();

	if (!InventoryComponent)
	{
		return false;
	}

	FLInventorySlot InventorySlot;

	if (!InventoryComponent->GetSlot(SlotIndex, InventorySlot)
		|| InventorySlot.IsEmpty()
		|| !InventorySlot.ItemData
		|| !InventorySlot.ItemData->IsWeapon())
	{
		return false;
	}

	TargetInventorySlotIndex = SlotIndex;
	bTargetEquippedWeapon = false;
	LastResultText = FText::GetEmpty();
	RefreshEnhanceWindow();
	BringToFront();
	return true;
}

bool ULWeaponEnhanceWindowWidget::TrySetTargetEquippedWeapon()
{
	ULInventoryComponent* InventoryComponent =
		ResolveInventoryComponent();

	if (!InventoryComponent)
	{
		return false;
	}

	FLInventorySlot EquippedWeaponSlot;

	if (!InventoryComponent->GetEquippedWeaponSlot(EquippedWeaponSlot))
	{
		return false;
	}

	TargetInventorySlotIndex = INDEX_NONE;
	bTargetEquippedWeapon = true;
	LastResultText = FText::GetEmpty();
	RefreshEnhanceWindow();
	BringToFront();
	return true;
}

void ULWeaponEnhanceWindowWidget::ClearEnhanceTarget()
{
	TargetInventorySlotIndex = INDEX_NONE;
	bTargetEquippedWeapon = false;
	LastResultText = FText::GetEmpty();
	RefreshEnhanceWindow();
}

void ULWeaponEnhanceWindowWidget::RefreshEnhanceWindow()
{
	ResolveDesignerWidgets();

	ULInventoryComponent* InventoryComponent =
		ResolveInventoryComponent();

	if (!InventoryComponent)
	{
		SetEmptyText();
		if (TXT_Status)
		{
			TXT_Status->SetText(FText::FromString(TEXT("No inventory.")));
		}
		return;
	}

	FLInventorySlot TargetSlot;

	if (!GetCurrentTargetSlot(TargetSlot))
	{
		SetEmptyText();
		return;
	}

	ULItemDataAsset* WeaponData = TargetSlot.ItemData;

	if (!WeaponData)
	{
		SetEmptyText();
		return;
	}

	SetTargetIcon(WeaponData->IconTexture);

	const int32 CurrentLevel = TargetSlot.EnhancementLevel;
	const int32 NextLevel = FMath::Min(
		CurrentLevel + 1,
		WeaponData->MaxEnhancementLevel
	);
	const int32 CurrentAttackPower =
		WeaponData->GetAttackPowerAtEnhancementLevel(CurrentLevel);
	const int32 NextAttackPower =
		WeaponData->GetAttackPowerAtEnhancementLevel(NextLevel);
	const int32 GoldCost =
		WeaponData->GetEnhanceGoldCost(CurrentLevel);
	const int32 MaterialCost =
		WeaponData->GetEnhanceMaterialCost(CurrentLevel);
	const float SuccessChance =
		WeaponData->GetEnhanceSuccessChance(CurrentLevel);

	if (TXT_Title)
	{
		TXT_Title->SetText(FText::FromString(TEXT("무기 강화")));
	}

	if (TXT_TargetName)
	{
		TXT_TargetName->SetText(WeaponData->DisplayName);
	}

	if (TXT_CurrentLevel)
	{
		TXT_CurrentLevel->SetText(
			FText::FromString(
				FString::Printf(TEXT("Enhancement  +%d -> +%d"), CurrentLevel, NextLevel)
			)
		);
	}

	if (TXT_AttackPower)
	{
		TXT_AttackPower->SetText(
			FText::FromString(
				FString::Printf(TEXT("Attack Power  %d -> %d"), CurrentAttackPower, NextAttackPower)
			)
		);
	}

	if (TXT_GoldCost)
	{
		TXT_GoldCost->SetText(
			FText::FromString(
				FString::Printf(TEXT("Gold  %d / %d"), InventoryComponent->GetGold(), GoldCost)
			)
		);
	}

	if (TXT_MaterialCost)
	{
		const int32 OwnedMaterialCount =
			WeaponData->EnhanceMaterialItemID.IsNone()
				? 0
				: InventoryComponent->CountItemByID(WeaponData->EnhanceMaterialItemID);

		TXT_MaterialCost->SetText(
			FText::FromString(
				FString::Printf(
					TEXT("%s  %d / %d"),
					*GetMaterialDisplayText(WeaponData->EnhanceMaterialItemID).ToString(),
					OwnedMaterialCount,
					MaterialCost
				)
			)
		);
	}

	if (TXT_SuccessChance)
	{
		TXT_SuccessChance->SetText(
			FText::FromString(
				FString::Printf(TEXT("Success Chance  %.0f%%"), SuccessChance * 100.0f)
			)
		);
	}

	FText FailureReason;
	const bool bCanEnhance =
		bTargetEquippedWeapon
			? InventoryComponent->CanEnhanceEquippedWeapon(FailureReason)
			: InventoryComponent->CanEnhanceWeaponAtSlot(
				TargetInventorySlotIndex,
				FailureReason
			);

	if (TXT_Status)
	{
		TXT_Status->SetText(
			bCanEnhance
				? FText::FromString(TEXT("Ready to enhance."))
				: FailureReason
		);
	}

	if (TXT_Result)
	{
		TXT_Result->SetText(LastResultText);
	}

	if (BTN_Enhance)
	{
		BTN_Enhance->SetIsEnabled(bCanEnhance);
	}
}

ULWeaponEnhanceWindowWidget*
ULWeaponEnhanceWindowWidget::GetActiveWeaponEnhanceWindow()
{
	ULWeaponEnhanceWindowWidget* ActiveWindow =
		ActiveWeaponEnhanceWindow.Get();

	if (!ActiveWindow)
	{
		return nullptr;
	}

	const ESlateVisibility Visibility =
		ActiveWindow->GetVisibility();

	if (Visibility == ESlateVisibility::Collapsed
		|| Visibility == ESlateVisibility::Hidden)
	{
		return nullptr;
	}

	return ActiveWindow;
}

void ULWeaponEnhanceWindowWidget::NativeConstruct()
{
	SetIsFocusable(true);
	EnsureWidgetTree();
	ResolveDesignerWidgets();
	BuildDefaultWidgetTree();

	Super::NativeConstruct();

	ResolveDesignerWidgets();
	NormalizeDesignerLayout();
	BindButtons();

	if (!ObservedPlayerCharacter)
	{
		ObservedPlayerCharacter = Cast<ALPlayerCharacter>(
			UGameplayStatics::GetPlayerCharacter(this, 0)
		);
	}

	ActiveWeaponEnhanceWindow = this;
	RefreshEnhanceWindow();

	if (!IsChangingWindowZOrder())
	{
		BringToFront();
	}
}

void ULWeaponEnhanceWindowWidget::NativeDestruct()
{
	if (!IsChangingWindowZOrder())
	{
		if (ActiveWeaponEnhanceWindow.Get() == this)
		{
			ActiveWeaponEnhanceWindow.Reset();
		}

		RestoreGameplayInputMode();
	}

	Super::NativeDestruct();
}

void ULWeaponEnhanceWindowWidget::NativeTick(
	const FGeometry& MyGeometry,
	float InDeltaTime
)
{
	Super::NativeTick(MyGeometry, InDeltaTime);
	RefreshEnhanceWindow();
}

FReply ULWeaponEnhanceWindowWidget::NativeOnKeyDown(
	const FGeometry& InGeometry,
	const FKeyEvent& InKeyEvent
)
{
	const FKey PressedKey = InKeyEvent.GetKey();

	if (PressedKey == EKeys::Escape || PressedKey == EKeys::G)
	{
		RemoveFromParent();
		return FReply::Handled();
	}

	return Super::NativeOnKeyDown(InGeometry, InKeyEvent);
}

FReply ULWeaponEnhanceWindowWidget::NativeOnPreviewKeyDown(
	const FGeometry& InGeometry,
	const FKeyEvent& InKeyEvent
)
{
	const FKey PressedKey = InKeyEvent.GetKey();

	if (PressedKey == EKeys::Escape || PressedKey == EKeys::G)
	{
		RemoveFromParent();
		return FReply::Handled();
	}

	return Super::NativeOnPreviewKeyDown(InGeometry, InKeyEvent);
}

bool ULWeaponEnhanceWindowWidget::NativeOnDrop(
	const FGeometry& InGeometry,
	const FDragDropEvent& InDragDropEvent,
	UDragDropOperation* InOperation
)
{
	ULUIDragDropOperation* DragOperation =
		Cast<ULUIDragDropOperation>(InOperation);

	if (!DragOperation || DragOperation->PayloadType != ELDragPayloadType::Item)
	{
		return false;
	}

	if (DragOperation->bFromEquipmentSlot)
	{
		return TrySetTargetEquippedWeapon();
	}

	if (DragOperation->SourceInventorySlotIndex == INDEX_NONE)
	{
		return false;
	}

	return TrySetTargetFromInventorySlot(
		DragOperation->SourceInventorySlotIndex
	);
}

void ULWeaponEnhanceWindowWidget::HandleEnhanceClicked()
{
	ULInventoryComponent* InventoryComponent =
		ResolveInventoryComponent();

	if (!InventoryComponent)
	{
		return;
	}

	FLWeaponEnhanceResult Result;
	const bool bAttempted =
		bTargetEquippedWeapon
			? InventoryComponent->EnhanceEquippedWeapon(Result)
			: InventoryComponent->EnhanceWeaponAtSlot(
				TargetInventorySlotIndex,
				Result
			);

	LastResultText =
		bAttempted
			? BuildResultText(Result)
			: Result.FailureReason;

	RefreshEnhanceWindow();
}

void ULWeaponEnhanceWindowWidget::HandleClearClicked()
{
	ClearEnhanceTarget();
}

void ULWeaponEnhanceWindowWidget::HandleCloseClicked()
{
	RemoveFromParent();
}

void ULWeaponEnhanceWindowWidget::ResolveDesignerWidgets()
{
	if (!IMG_TargetIcon)
	{
		IMG_TargetIcon = Cast<UImage>(GetWidgetFromName(TEXT("IMG_TargetIcon")));
	}

	if (!TXT_Title)
	{
		TXT_Title = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_Title")));
	}

	if (!TXT_TargetName)
	{
		TXT_TargetName = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_TargetName")));
	}

	if (!TXT_CurrentLevel)
	{
		TXT_CurrentLevel = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_CurrentLevel")));
	}

	if (!TXT_AttackPower)
	{
		TXT_AttackPower = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_AttackPower")));
	}

	if (!TXT_GoldCost)
	{
		TXT_GoldCost = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_GoldCost")));
	}

	if (!TXT_MaterialCost)
	{
		TXT_MaterialCost = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_MaterialCost")));
	}

	if (!TXT_SuccessChance)
	{
		TXT_SuccessChance = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_SuccessChance")));
	}

	if (!TXT_Status)
	{
		TXT_Status = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_Status")));
	}

	if (!TXT_Result)
	{
		TXT_Result = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_Result")));
	}

	if (!TXT_EnhanceButton)
	{
		TXT_EnhanceButton = Cast<UTextBlock>(GetWidgetFromName(TEXT("TXT_EnhanceButton")));
	}

	if (!BTN_Enhance)
	{
		BTN_Enhance = Cast<UButton>(GetWidgetFromName(TEXT("BTN_Enhance")));
	}

	if (!BTN_Clear)
	{
		BTN_Clear = Cast<UButton>(GetWidgetFromName(TEXT("BTN_Clear")));
	}

	if (!BTN_Close)
	{
		BTN_Close = Cast<UButton>(GetWidgetFromName(TEXT("BTN_Close")));
	}

	if (!WBP_DragHandle)
	{
		WBP_DragHandle = GetWidgetFromName(TEXT("WBP_DragHandle"));
	}
}

void ULWeaponEnhanceWindowWidget::BuildDefaultWidgetTree()
{
	EnsureWidgetTree();

	if (!WidgetTree || !bUseCodeGeneratedLayout)
	{
		return;
	}

	if (WidgetTree->RootWidget
		&& IMG_TargetIcon
		&& BTN_Enhance
		&& TXT_TargetName)
	{
		return;
	}

	UCanvasPanel* RootCanvas =
		WidgetTree->ConstructWidget<UCanvasPanel>(UCanvasPanel::StaticClass());
	WidgetTree->RootWidget = RootCanvas;

	UBorder* WindowBorder =
		WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass());
	WindowBorder->SetBrushColor(FLinearColor(0.01f, 0.013f, 0.018f, 0.98f));
	WindowBorder->SetPadding(FMargin(14.0f));

	UCanvasPanelSlot* WindowSlot =
		RootCanvas->AddChildToCanvas(WindowBorder);
	WindowSlot->SetAnchors(FAnchors(0.5f, 0.5f));
	WindowSlot->SetAlignment(FVector2D(0.5f, 0.5f));
	WindowSlot->SetSize(FVector2D(560.0f, 430.0f));
	WindowSlot->SetPosition(FVector2D::ZeroVector);

	UVerticalBox* RootBox =
		WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass());
	WindowBorder->SetContent(RootBox);

	UBorder* TitleBar =
		WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass(), TEXT("WBP_DragHandle"));
	TitleBar->SetBrushColor(FLinearColor(0.08f, 0.07f, 0.045f, 1.0f));
	TitleBar->SetPadding(FMargin(10.0f, 6.0f));
	WBP_DragHandle = TitleBar;

	UVerticalBoxSlot* TitleBarSlot =
		RootBox->AddChildToVerticalBox(TitleBar);
	TitleBarSlot->SetSize(FSlateChildSize(ESlateSizeRule::Automatic));
	TitleBarSlot->SetPadding(FMargin(0.0f, 0.0f, 0.0f, 12.0f));

	UHorizontalBox* TitleRow =
		WidgetTree->ConstructWidget<UHorizontalBox>(UHorizontalBox::StaticClass());
	TitleBar->SetContent(TitleRow);

	TXT_Title =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_Title"));
	TXT_Title->SetText(FText::FromString(TEXT("무기 강화")));
	TXT_Title->SetJustification(ETextJustify::Center);
	TXT_Title->SetColorAndOpacity(FSlateColor(FLinearColor(1.0f, 0.86f, 0.42f, 1.0f)));
	UHorizontalBoxSlot* TitleSlot =
		TitleRow->AddChildToHorizontalBox(TXT_Title);
	TitleSlot->SetSize(FSlateChildSize(ESlateSizeRule::Fill));

	BTN_Close =
		WidgetTree->ConstructWidget<UButton>(UButton::StaticClass(), TEXT("BTN_Close"));
	UTextBlock* CloseText =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
	CloseText->SetText(FText::FromString(TEXT("X")));
	CloseText->SetJustification(ETextJustify::Center);
	BTN_Close->AddChild(CloseText);
	UHorizontalBoxSlot* CloseSlot =
		TitleRow->AddChildToHorizontalBox(BTN_Close);
	CloseSlot->SetSize(FSlateChildSize(ESlateSizeRule::Automatic));

	UHorizontalBox* ContentRow =
		WidgetTree->ConstructWidget<UHorizontalBox>(UHorizontalBox::StaticClass());
	UVerticalBoxSlot* ContentSlot =
		RootBox->AddChildToVerticalBox(ContentRow);
	ContentSlot->SetSize(FSlateChildSize(ESlateSizeRule::Fill));

	UVerticalBox* LeftBox =
		WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass());
	UHorizontalBoxSlot* LeftSlot =
		ContentRow->AddChildToHorizontalBox(LeftBox);
	LeftSlot->SetSize(FSlateChildSize(ESlateSizeRule::Automatic));
	LeftSlot->SetPadding(FMargin(0.0f, 0.0f, 16.0f, 0.0f));

	USizeBox* SlotSizeBox =
		WidgetTree->ConstructWidget<USizeBox>(USizeBox::StaticClass());
	SlotSizeBox->SetWidthOverride(132.0f);
	SlotSizeBox->SetHeightOverride(132.0f);
	LeftBox->AddChildToVerticalBox(SlotSizeBox);

	UBorder* TargetBorder =
		WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass());
	TargetBorder->SetBrushColor(FLinearColor(0.025f, 0.03f, 0.035f, 1.0f));
	TargetBorder->SetPadding(FMargin(8.0f));
	SlotSizeBox->AddChild(TargetBorder);

	UOverlay* TargetOverlay =
		WidgetTree->ConstructWidget<UOverlay>(UOverlay::StaticClass());
	TargetBorder->SetContent(TargetOverlay);

	IMG_TargetIcon =
		WidgetTree->ConstructWidget<UImage>(UImage::StaticClass(), TEXT("IMG_TargetIcon"));
	if (UOverlaySlot* IconSlot =
		TargetOverlay->AddChildToOverlay(IMG_TargetIcon))
	{
		IconSlot->SetHorizontalAlignment(HAlign_Fill);
		IconSlot->SetVerticalAlignment(VAlign_Fill);
	}

	TXT_TargetName =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_TargetName"));
	TXT_TargetName->SetJustification(ETextJustify::Center);
	TXT_TargetName->SetColorAndOpacity(FSlateColor(FLinearColor(0.92f, 0.94f, 1.0f, 1.0f)));
	UVerticalBoxSlot* NameSlot =
		LeftBox->AddChildToVerticalBox(TXT_TargetName);
	NameSlot->SetPadding(FMargin(0.0f, 10.0f, 0.0f, 0.0f));

	UVerticalBox* StatBox =
		WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass());
	UHorizontalBoxSlot* StatSlot =
		ContentRow->AddChildToHorizontalBox(StatBox);
	StatSlot->SetSize(FSlateChildSize(ESlateSizeRule::Fill));

	TXT_CurrentLevel =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_CurrentLevel"));
	TXT_AttackPower =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_AttackPower"));
	TXT_GoldCost =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_GoldCost"));
	TXT_MaterialCost =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_MaterialCost"));
	TXT_SuccessChance =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_SuccessChance"));
	TXT_Status =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_Status"));
	TXT_Result =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_Result"));

	const TArray<UTextBlock*> StatTexts = {
		TXT_CurrentLevel,
		TXT_AttackPower,
		TXT_GoldCost,
		TXT_MaterialCost,
		TXT_SuccessChance,
		TXT_Status,
		TXT_Result
	};

	for (UTextBlock* StatText : StatTexts)
	{
		if (!StatText)
		{
			continue;
		}

		StatText->SetColorAndOpacity(FSlateColor(FLinearColor(0.86f, 0.9f, 0.94f, 1.0f)));
		UVerticalBoxSlot* TextSlot =
			StatBox->AddChildToVerticalBox(StatText);
		TextSlot->SetPadding(FMargin(0.0f, 0.0f, 0.0f, 9.0f));
	}

	UHorizontalBox* ButtonRow =
		WidgetTree->ConstructWidget<UHorizontalBox>(UHorizontalBox::StaticClass());
	UVerticalBoxSlot* ButtonRowSlot =
		RootBox->AddChildToVerticalBox(ButtonRow);
	ButtonRowSlot->SetSize(FSlateChildSize(ESlateSizeRule::Automatic));
	ButtonRowSlot->SetPadding(FMargin(0.0f, 14.0f, 0.0f, 0.0f));

	BTN_Clear =
		WidgetTree->ConstructWidget<UButton>(UButton::StaticClass(), TEXT("BTN_Clear"));
	UTextBlock* ClearText =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
	ClearText->SetText(FText::FromString(TEXT("비우기")));
	ClearText->SetJustification(ETextJustify::Center);
	BTN_Clear->AddChild(ClearText);
	UHorizontalBoxSlot* ClearSlot =
		ButtonRow->AddChildToHorizontalBox(BTN_Clear);
	ClearSlot->SetSize(FSlateChildSize(ESlateSizeRule::Fill));
	ClearSlot->SetPadding(FMargin(0.0f, 0.0f, 8.0f, 0.0f));

	BTN_Enhance =
		WidgetTree->ConstructWidget<UButton>(UButton::StaticClass(), TEXT("BTN_Enhance"));
	TXT_EnhanceButton =
		WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), TEXT("TXT_EnhanceButton"));
	TXT_EnhanceButton->SetText(FText::FromString(TEXT("강화")));
	TXT_EnhanceButton->SetJustification(ETextJustify::Center);
	BTN_Enhance->AddChild(TXT_EnhanceButton);
	UHorizontalBoxSlot* EnhanceSlot =
		ButtonRow->AddChildToHorizontalBox(BTN_Enhance);
	EnhanceSlot->SetSize(FSlateChildSize(ESlateSizeRule::Fill));
}

void ULWeaponEnhanceWindowWidget::EnsureWidgetTree()
{
	if (WidgetTree)
	{
		return;
	}

	WidgetTree = NewObject<UWidgetTree>(
		this,
		TEXT("WidgetTree"),
		RF_Transient
	);
}

void ULWeaponEnhanceWindowWidget::NormalizeDesignerLayout()
{
	if (WBP_DragHandle)
	{
		bool bUseHitTestableDragHandle = false;

		if (UCanvasPanelSlot* DragHandleCanvasSlot =
			Cast<UCanvasPanelSlot>(WBP_DragHandle->Slot))
		{
			DragHandleCanvasSlot->SetZOrder(0);

			const FVector2D DragHandleSize =
				DragHandleCanvasSlot->GetSize();

			bUseHitTestableDragHandle =
				DragHandleSize.X > 1.0f
				&& DragHandleSize.Y > 1.0f
				&& DragHandleSize.Y <= 96.0f;
		}

		WBP_DragHandle->SetVisibility(
			bUseHitTestableDragHandle
				? ESlateVisibility::Visible
				: ESlateVisibility::SelfHitTestInvisible
		);
	}

	if (BTN_Close)
	{
		BTN_Close->SetVisibility(ESlateVisibility::Visible);
		BTN_Close->SetIsEnabled(true);
		EnsureButtonCanvasSlotSize(BTN_Close, FVector2D(36.0f, 36.0f));
	}

	if (BTN_Clear)
	{
		BTN_Clear->SetVisibility(ESlateVisibility::Visible);
		BTN_Clear->SetIsEnabled(true);
		EnsureButtonCanvasSlotSize(BTN_Clear, FVector2D(96.0f, 36.0f));
	}

	if (BTN_Enhance)
	{
		BTN_Enhance->SetVisibility(ESlateVisibility::Visible);
		EnsureButtonCanvasSlotSize(BTN_Enhance, FVector2D(180.0f, 44.0f));
	}
}

void ULWeaponEnhanceWindowWidget::EnsureButtonCanvasSlotSize(
	UWidget* Widget,
	const FVector2D& FallbackSize
) const
{
	if (!Widget)
	{
		return;
	}

	UCanvasPanelSlot* CanvasSlot =
		Cast<UCanvasPanelSlot>(Widget->Slot);

	if (!CanvasSlot)
	{
		return;
	}

	CanvasSlot->SetZOrder(100);

	const FVector2D CurrentSize =
		CanvasSlot->GetSize();

	if (CurrentSize.X > 1.0f && CurrentSize.Y > 1.0f)
	{
		return;
	}

	CanvasSlot->SetAutoSize(false);
	CanvasSlot->SetSize(FallbackSize);
}

void ULWeaponEnhanceWindowWidget::BindButtons()
{
	if (BTN_Enhance)
	{
		BTN_Enhance->OnClicked.RemoveAll(this);
		BTN_Enhance->OnClicked.AddDynamic(
			this,
			&ULWeaponEnhanceWindowWidget::HandleEnhanceClicked
		);
	}

	if (BTN_Clear)
	{
		BTN_Clear->OnClicked.RemoveAll(this);
		BTN_Clear->OnClicked.AddDynamic(
			this,
			&ULWeaponEnhanceWindowWidget::HandleClearClicked
		);
	}

	if (BTN_Close)
	{
		BTN_Close->OnClicked.RemoveAll(this);
		BTN_Close->OnClicked.AddDynamic(
			this,
			&ULWeaponEnhanceWindowWidget::HandleCloseClicked
		);
	}
}

void ULWeaponEnhanceWindowWidget::RestoreGameplayInputMode() const
{
	APlayerController* OwningPlayerController =
		GetOwningPlayer();

	if (!OwningPlayerController)
	{
		return;
	}

	OwningPlayerController->StopMovement();
	OwningPlayerController->bShowMouseCursor = true;

	UWidgetBlueprintLibrary::SetInputMode_GameAndUIEx(
		OwningPlayerController,
		nullptr,
		EMouseLockMode::DoNotLock,
		false,
		true
	);
}

ULInventoryComponent*
ULWeaponEnhanceWindowWidget::ResolveInventoryComponent() const
{
	ALPlayerCharacter* PlayerCharacter =
		ObservedPlayerCharacter;

	if (!PlayerCharacter)
	{
		PlayerCharacter = Cast<ALPlayerCharacter>(
			UGameplayStatics::GetPlayerCharacter(this, 0)
		);
	}

	return PlayerCharacter
		? PlayerCharacter->GetInventoryComponent()
		: nullptr;
}

bool ULWeaponEnhanceWindowWidget::GetCurrentTargetSlot(
	FLInventorySlot& OutSlot
) const
{
	OutSlot.Clear();

	ULInventoryComponent* InventoryComponent =
		ResolveInventoryComponent();

	if (!InventoryComponent)
	{
		return false;
	}

	if (bTargetEquippedWeapon)
	{
		return InventoryComponent->GetEquippedWeaponSlot(OutSlot);
	}

	if (TargetInventorySlotIndex == INDEX_NONE)
	{
		return false;
	}

	return InventoryComponent->GetSlot(
		TargetInventorySlotIndex,
		OutSlot
	)
		&& !OutSlot.IsEmpty()
		&& OutSlot.ItemData
		&& OutSlot.ItemData->IsWeapon();
}

FText ULWeaponEnhanceWindowWidget::GetMaterialDisplayText(
	FName MaterialItemID
) const
{
	if (MaterialItemID.IsNone())
	{
		return FText::FromString(TEXT("Material"));
	}

	ULInventoryComponent* InventoryComponent =
		ResolveInventoryComponent();

	if (!InventoryComponent)
	{
		return FText::FromName(MaterialItemID);
	}

	const FString ExpectedID = MaterialItemID.ToString();
	const FString DataAssetName = FString(TEXT("DA_")) + ExpectedID;

	for (const FLInventorySlot& InventorySlot : InventoryComponent->GetSlots())
	{
		if (!InventorySlot.IsEmpty()
			&& InventorySlot.ItemData
			&& (InventorySlot.ItemData->ItemID == MaterialItemID
				|| InventorySlot.ItemData->GetName().Equals(
					ExpectedID,
					ESearchCase::IgnoreCase
				)
				|| InventorySlot.ItemData->GetName().Equals(
					DataAssetName,
					ESearchCase::IgnoreCase
				)
				|| InventorySlot.ItemData->DisplayName.ToString().Equals(
					ExpectedID,
					ESearchCase::IgnoreCase
				)))
		{
			return InventorySlot.ItemData->DisplayName;
		}
	}

	return FText::FromName(MaterialItemID);
}

FText ULWeaponEnhanceWindowWidget::BuildResultText(
	const FLWeaponEnhanceResult& Result
) const
{
	if (!Result.bAttempted)
	{
		return Result.FailureReason;
	}

	if (Result.bSuccess)
	{
		return FText::FromString(
			FString::Printf(
				TEXT("Success  +%d -> +%d"),
				Result.PreviousLevel,
				Result.NewLevel
			)
		);
	}

	return FText::FromString(
		FString::Printf(
			TEXT("Failed  +%d remains"),
			Result.PreviousLevel
		)
	);
}

void ULWeaponEnhanceWindowWidget::SetTargetIcon(
	UTexture2D* IconTexture
)
{
	if (!IMG_TargetIcon)
	{
		return;
	}

	if (!IconTexture)
	{
		IMG_TargetIcon->SetRenderOpacity(0.0f);
		return;
	}

	IMG_TargetIcon->SetBrushFromTexture(IconTexture, false);
	IMG_TargetIcon->SetDesiredSizeOverride(FVector2D(112.0f, 112.0f));
	IMG_TargetIcon->SetRenderOpacity(1.0f);
}

void ULWeaponEnhanceWindowWidget::SetEmptyText()
{
	SetTargetIcon(nullptr);

	if (TXT_Title)
	{
		TXT_Title->SetText(FText::FromString(TEXT("무기 강화")));
	}

	if (TXT_TargetName)
	{
		TXT_TargetName->SetText(FText::FromString(TEXT("Drop weapon here")));
	}

	if (TXT_CurrentLevel)
	{
		TXT_CurrentLevel->SetText(FText::FromString(TEXT("Enhancement  -")));
	}

	if (TXT_AttackPower)
	{
		TXT_AttackPower->SetText(FText::FromString(TEXT("Attack Power  -")));
	}

	if (TXT_GoldCost)
	{
		TXT_GoldCost->SetText(FText::FromString(TEXT("Gold  -")));
	}

	if (TXT_MaterialCost)
	{
		TXT_MaterialCost->SetText(FText::FromString(TEXT("Material  -")));
	}

	if (TXT_SuccessChance)
	{
		TXT_SuccessChance->SetText(FText::FromString(TEXT("Success Chance  -")));
	}

	if (TXT_Status)
	{
		TXT_Status->SetText(
			FText::FromString(TEXT("Drag a weapon here or right-click a weapon in inventory."))
		);
	}

	if (TXT_Result)
	{
		TXT_Result->SetText(LastResultText);
	}

	if (BTN_Enhance)
	{
		BTN_Enhance->SetIsEnabled(false);
	}
}
